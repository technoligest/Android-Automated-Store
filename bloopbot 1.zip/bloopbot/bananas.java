package com.zackrooney.bloopbot;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by zackrooney on 2016-04-29.
 */
public class bananas extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bananas);
    }
}
