package com.zackrooney.bloopbot;


import com.squareup.okhttp.ResponseBody;

import java.util.List;


import retrofit.Call;
import retrofit.http.GET;
import retrofit.http.POST;
import retrofit.http.Path;
import retrofit.http.Query;

/*
 * Created by zackrooney on 2016-04-30.
 *
 */
public interface ZaherInterface {
    //http://ooper.space/VoltaHackathon2016/api.php?type=refresh&pass=wordpass
    @GET("api.php")
    Call<List<ZaherHelp>> api(@Query("type")String type,@Query("pass")String pass );
    //api.php?type=insert&pass=wordpass&name=anything&back=##&location=ssss
    @GET("api.php")
   Call<ResponseBody>  add(@Query("type")String type,@Query("pass")String pass
            ,@Query("name")String name,@Query("back")int back,@Query("location")String location );

}
