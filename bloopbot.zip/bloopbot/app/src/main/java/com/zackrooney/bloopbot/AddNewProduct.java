package com.zackrooney.bloopbot;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

/**
 * Created by zackrooney on 2016-04-30.
 */
public class AddNewProduct extends Activity {

    Button button4;
    EditText editText, editText2, editText3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_new_product);
    }
}
