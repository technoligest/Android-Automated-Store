package com.zackrooney.bloopbot;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 * Created by zackrooney on 2016-04-29.
 */
public class MainActivity extends Activity {
    private static
    ArrayList<Product> list= new ArrayList<Product>();
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);

        listView = (ListView) findViewById(R.id.BananaList);
        String []values={"Yaser"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, android.R.id.text1, values);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int itemPosition = position;
                String itemValue = (String) listView.getItemAtPosition(position);
                Toast.makeText(getApplicationContext(), "Position :" + itemPosition + "  ListItem : " + itemValue, Toast.LENGTH_LONG).show();
                startActivity(new Intent(MainActivity.this, bananas.class));
            }

        });
        try {
            displayDatabase();
        }
        catch(Exception e){
            System.out.print("NO");
        }
    }
/*
    public static boolean addItem(String name, int back,String location) throws Exception{
        try {

            URL myURL = new URL("http://ooper.space/VoltaHackathon2016/api.php?type=insert&pass=wordpass&name="+name+"&back="+back+"&location="+location);

            JSONArray array = (JSONArray)(new JSONParser()).parse(readUrlJson("http://ooper.space/VoltaHackathon2016/api.php?type=refresh&pass=wordpass"));
            JSONObject obj = (JSONObject)array.get(array.size()-1);
            list.add(new Product(name, Integer.parseInt((String)obj.get("id")), location, back));
            myURL.openStream();
        }
        catch (Exception e) {
            System.out.println("OOPS");
            return false;
        }
        return true;
    }*/



    //this function displays the database in an nice format
    public static void displayDatabase() throws Exception{
        String stringFormat="%-15s %-6s %-10s %-6s %-6s %-19s";
        String s = readUrlJson("http://ooper.space/VoltaHackathon2016/api.php?type=refresh&pass=wordpass");
        JSONArray array = (JSONArray)(new JSONParser()).parse(s);
        System.out.println(String.format(stringFormat, "Name", "Back","location", "Id", "Front", "Expiry"));
        StringTokenizer st1, st2;
        String s1;
        ArrayList<String> arr;
        for(int i=0; i<array.size(); i++){
            arr = new ArrayList<String>();
            st1 = new StringTokenizer( (((JSONObject)(array.get(i))).entrySet()).toString(),",");
            //System.out.println((((JSONObject)(array.get(i))).entrySet()).toString());
            while(st1.hasMoreTokens()){
                st2=new StringTokenizer(st1.nextToken(), "=");
                s1=st2.nextToken();
                s1="NO";
                //if there is a value associated with the variable
                if(st2.hasMoreElements())
                    s1=st2.nextToken();

                //if there is no next item in the list then just remove the last bracket.
                if(!st1.hasMoreElements() && !s1.equals("NO"))
                    s1=s1.substring(0, s1.length()-1);

                arr.add(s1);
            }
            System.out.println(String.format(stringFormat,arr.get(0),arr.get(1),arr.get(2),arr.get(3),arr.get(4), arr.get(5)));
        }
    }

    //this function takes in a url and returns out the associated Json code
    private static String readUrlJson(String urlString) throws Exception {
        BufferedReader reader = null;
        try {
            URL url = new URL(urlString);
            reader = new BufferedReader(new InputStreamReader(url.openStream()));
            StringBuffer buffer = new StringBuffer();
            int read;
            char[] chars = new char[1024];
            while ((read = reader.read(chars)) != -1)
                buffer.append(chars, 0, read);

            return buffer.toString();
        } finally {
            if (reader != null)
                reader.close();
        }
    }


    /* final ListView listview = (ListView) findViewById(R.id.listview);
     String[] values = new String[] { "Apples", "Bananas", "Cereal", "Bread", "Oreos", "Red Bull" };

     final ArrayList<String> list = new ArrayList<String>();
     for (int i = 0; i < values.length; ++i) {
         list.add(values[i]);
     }
     final StableArrayAdapter adapter = new StableArrayAdapter(this,
             android.R.layout.simple_list_item_1, list);
     listview.setAdapter(adapter);

     listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {

         @Override
         public void onItemClick(AdapterView<?> parent, final View view,
         int position, long id) {
             final String item = (String) parent.getItemAtPosition(position);
             view.animate().setDuration(2000).alpha(0)
                     .withEndAction(new Runnable() {
                         @Override
                         public void run() {
                             list.remove(item);
                             adapter.notifyDataSetChanged();
                             view.setAlpha(1);
                         }
                     });
         }

     });
 }

 private class StableArrayAdapter extends ArrayAdapter<String> {

     HashMap<String, Integer> mIdMap = new HashMap<String, Integer>();

     public StableArrayAdapter(Context context, int textViewResourceId,
                               List<String> objects) {
         super(context, textViewResourceId, objects);
         for (int i = 0; i < objects.size(); ++i) {
             mIdMap.put(objects.get(i), i);
         }
     }

     @Override
     public long getItemId(int position) {
         String item = getItem(position);
         return mIdMap.get(item);
     }

     @Override
     public boolean hasStableIds() {
         return true;
     }

 */
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.restock) {
            //wait for more information
        }

        if (id == R.id.addrow) {

        }

        return super.onOptionsItemSelected(item);
    }

}
//}


