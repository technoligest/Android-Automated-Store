package com.zackrooney.bloopbot;


import java.util.List;

import retrofit.Call;
import retrofit.http.GET;
import retrofit.http.Path;

/**
 * Created by zackrooney on 2016-04-30.
 *
 */
public interface ZaherInterface {
    //http://ooper.space/VoltaHackathon2016/api.php?type=refresh&pass=wordpass
    @GET("api.php?{type},{pass}")
    Call<List<ZaherHelp>> api(@Path("type")String type,@Path("pass")String pass );
}
